-VOPM Mega Arcade Collection v1.0-

by Luke McQueen - http://www.youtube.com/mcqueen8601

Over 1000 .OPM patches from the most famous arcade games 
to use the Yamaha YM2151 as their main sound chip.


N.B. 
Many of the patches from single tracks are split into two or more files. 
That's because the games switch patches dynamically, so I had to dump the tracks several times while playing them. 
I'm sure some sounds got lost in the shuffle, but you'll hardly notice it anyway.


Software Used:

Hoot Player - http://snesmusic.org/hoot/v2/
Hoot Voice Ripper - http://nrtdrv.sakura.ne.jp/index.cgi?page=%A5%C0%A5%A6%A5%F3%A5%ED%A1%BC%A5%C9#p4

BIG thanks to the authors of these awesome tools. 
This release wouldn't have been possible without you.